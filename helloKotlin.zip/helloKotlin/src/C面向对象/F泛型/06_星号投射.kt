package C面向对象.F泛型

/**
 * A类    名:  `06_星号投射`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/27 10:08
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
//    Function<*, String> , 代表 Function< in Nothing, String> ;
//    Function<Int, *> , 代表 Function<Int, out Any?> ;
//    Function<, > , 代表 Function< in Nothing, out Any?> .
}