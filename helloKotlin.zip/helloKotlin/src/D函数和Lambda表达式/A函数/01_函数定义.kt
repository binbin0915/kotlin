package D函数和Lambda表达式.A函数

/**
 * 类    名:  `01_函数定义`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/8/3 11:12
 * 描    述： ${TODO}
 */
fun hah(): Unit {
    println("hah")
}