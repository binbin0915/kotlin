package B流控语句

/**
 * A类    名:  使用区间
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/24 16:34
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
    val x = 5
    val y = 9
   if(x in 1..8){
       print("x 在区间里面")
   }
}