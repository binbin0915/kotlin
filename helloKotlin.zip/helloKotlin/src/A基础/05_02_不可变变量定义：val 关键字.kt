package A基础

/**
 * A类    名:  `05_02_不可变变量定义：val 关键字`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/24 11:06
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
    //定义
    val a: Int

    //定义并赋值
    val b: Int = 10

    //定义和赋值分开,只能赋值一次
    val c: Int
    c = 10;

    //不能二次赋值
//    c = 11;
}