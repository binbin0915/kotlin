 /**
 * A类    名:  `03_02_有参函数`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/24 10:23
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
    myFun2(1,1)
}

fun myFun2(a: Int, b: Int) {
    print("a:" + a + " b:" + b)
}
