package A基础

/**
 * A类    名:  `Kotlin 基本数据类型`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/24 14:18
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
    //整型 Int Long
    var a = 10
    var b = 10L

    //浮点型 Float Double
    var c = 10.0f
    var d = 10F
    var e = 10e10 //科学计数法

    //字符型 Char String
    var f = 'C'
    var h = "CCCC"

    //字节型 Byte
    var i: Byte = 1


}