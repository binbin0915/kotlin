/**
 * A类    名:  `03_打印方法`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/24 10:21
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
    print("hello");
    println()
    print("world")
}