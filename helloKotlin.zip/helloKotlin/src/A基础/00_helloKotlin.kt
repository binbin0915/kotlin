/**
 * 类    名:  helloKotlin
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/12 9:36
 * 描    述： ${TODO}
 */
package hello                      //  可选的包头

fun main(args: Array<String>) {    // 包级可见的函数，接受一个字符串数组作为参数
    println("Hello World!")         // 分号可以省略
}
