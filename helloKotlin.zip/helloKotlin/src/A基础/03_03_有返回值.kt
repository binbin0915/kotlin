/**
 * A类    名:  `03_03_有返回值`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/24 10:26
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
    print("1+1="+ myFun3(1,1))
}
fun myFun3(a:Int, b:Int): Int {
    return a+b;
}