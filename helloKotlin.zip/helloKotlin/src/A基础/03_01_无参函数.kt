/**
 * A类    名:  `03_01_无参函数`
 * 创 建 者:  伍碧林
 * 创建时间:  2017/7/24 10:22
 * 描    述： ${TODO}
 */
fun main(args: Array<String>) {
    myFun1();
}

fun myFun1(){
    print("myMethod")
}