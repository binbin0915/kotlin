plugins {
    java
}

