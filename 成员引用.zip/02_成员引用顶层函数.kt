package ch05.ex1_5_1_MemberReferences

//顶层函数
fun salute() = println("Salute!")

fun main(args: Array<String>) {
    //成员引用引用顶层函数
    run(::salute)
}
/*
4.引用顶层函数
 */