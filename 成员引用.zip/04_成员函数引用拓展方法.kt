package ch05.ex1_5_2_MemberReferences2

data class Person(val name: String, val age: Int)

fun Person.isAdult() = age >= 21

fun main(args: Array<String>) {
    val person = Person("billy", 22)
    val predicate = Person::isAdult
    println(predicate(person))
}
/*
成员引用引用拓展函数
 */