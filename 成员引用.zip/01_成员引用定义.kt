package 第6章Lambda成员引用高阶函数.C成员引用

/**
 * 类    名:  `01_成员引用`
 * 创 建 者:  黑马程序员
 * 描    述： ${TODO}
 */
class Person(val name: String, val age: Int)

fun main(args: Array<String>) {
    val person = Person("billy", 18)
    //打印姓名
    println(person.name)

    //成员引用的方式打印
    val kProperty1 = Person::name
    kProperty1(person)
}

/*
1.Kotlin和Java8一样,如果把函数转换成一个值,你就可以传递它.
2.成员引用,提供了简明语法,来创建一个调用单个方法或者访问单个属性的函数值.
3.成员引用属性  Person::age
 */