package ch05.ex1_5_2_MemberReferences1

data class Person(val name: String, val age: Int)



fun main(args: Array<String>) {
    val createPerson = ::Person
    val p = createPerson("Alice", 29)
    println(p)
}
/*
构造方法引用存储或延期执行创建类实例的动作
 */