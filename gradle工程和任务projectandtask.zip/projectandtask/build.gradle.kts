task("closedoor",{
    doFirst {
        println("关冰箱门")
    }
}).dependsOn("putelephant")
task("opendoor",{
    doFirst { println("开冰箱门") }
})
task("putelephant",{
    doFirst { println("放入大象") }
}).dependsOn("opendoor")

task("haha",{
    var haha = "afdaf" //扫描时执行
    doFirst {  }//在运行时执行
    doLast {  } //运行时执行
})