task("haha",{
    //执行一段java代码
    javaexec {
        main = "Hello"
        classpath(".")
    }
})
